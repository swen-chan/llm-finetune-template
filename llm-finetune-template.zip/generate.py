import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

# 加载训练后的模型
model_path = "model"
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForCausalLM.from_pretrained(model_path)

model.eval()
prompt = "To be"
input_ids = tokenizer(prompt, return_tensors="pt").input_ids

# 文本生成
with torch.no_grad():
    outputs = model.generate(
        input_ids,
        max_length=50,
        do_sample=True,
        top_k=50,
        top_p=0.95,
        num_return_sequences=1
    )

# 打印结果
print(tokenizer.decode(outputs[0], skip_special_tokens=True))
